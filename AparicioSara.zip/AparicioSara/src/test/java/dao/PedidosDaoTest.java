/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author sara
 */
public class PedidosDaoTest {

    static PedidosDao pedidos = new PedidosDao();
    static Pedido pedido = new Pedido();
    public PedidosDaoTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testGetConexion() {
        System.out.println("getConexion");
        PedidosDao instance = new PedidosDao();
        Connection expResult = null;
        Connection result = instance.getConexion();
        assertNotEquals(expResult, result);
    }

    @Test
    public void testRead() {
        System.out.println("read");
        Integer idPedido = 11056;
        Pedido result = pedidos.read(idPedido);
        assertEquals(result.getId(), idPedido);
    }

    @Test
    public void testInsert() {
        System.out.println("insert");
        //estamos creando objetos que ya existen asi que normal que de error
        pedido = new Pedido(11111, 20, 4, new Date(1996-07-02), new Date(1996-07-02), new Date(1996-07-02), 2, new BigDecimal(32.3800) , "Wilman hdfg", "fghfghfgh 45", "Helsinki", null, "21740", "Finlandia");
        Boolean expResult = true;
        Integer result = pedidos.insert(pedido);
        assertEquals(result, pedido.getId());
    }
 
    /*@Test
    public void testUpdate() {
       System.out.println("update");
        Pedido pedido = null;
        Boolean expResult = false;
        Integer result = pedidos.update(pedido);
        assertEquals(expResult, result);
    }*/

    @Test
    public void testDelete() {
        System.out.println("delete");
        PedidosDao instance = new PedidosDao();
        Pedido expResult =new Pedido(12155, 3, 2, new Date(1996-07-02), new Date(1996-07-02), new Date(1996-07-02), 5, new BigDecimal(100.2580) , "gsdfg gsdfgsd", "fadfa fsdfsd", "Madrid", "adkshgbdjas", "dahbfafs", "fsdfjgda");
        int result = instance.delete(expResult.getId());
        assertNotEquals(result, -1);
        
        result = instance.delete(10248);
        assertEquals(result, -1);
    }

    @Test
    public void testListar() {
        System.out.println("listar");
        Integer start = 5;
        ArrayList<Pedido> expResult = new ArrayList<Pedido>();
        Pedido pedido2 =new Pedido(11117, 3, 2, new Date(1996-07-02), new Date(1996-07-02), new Date(1996-07-02), 5, new BigDecimal(100.2580) , "gsdfg gsdfgsd", "fadfa fsdfsd", "Madrid", "adkshgbdjas", "dahbfafs", "fsdfjgda");
        expResult.add(pedido2);
        ArrayList<Pedido> result = pedidos.listar(start);
        assertEquals(result.get(0).getId(), pedido.getId());
    }
    
}
